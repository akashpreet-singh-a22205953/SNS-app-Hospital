package pt.ulusofona.deisi.cm.prjectcm.prjectcm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
