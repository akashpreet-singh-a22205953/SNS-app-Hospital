import 'package:integration_test/integration_test.dart';

import '../test/widget_teacher_mandatory_test.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  runWidgetTests();
}