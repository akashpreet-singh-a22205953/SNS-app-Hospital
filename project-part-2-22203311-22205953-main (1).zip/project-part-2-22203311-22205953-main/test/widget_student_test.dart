import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:prjectcm/connectivity_module.dart';
import 'package:prjectcm/data/http_sns_datasource.dart';
import 'package:prjectcm/data/sqflite_sns_datasource.dart';
import 'package:prjectcm/location_module.dart';
import 'package:prjectcm/main.dart';
import 'package:prjectcm/models/hospital.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:testable_form_field/testable_form_field.dart';

import 'fake_connectivity_module.dart';
import 'fake_http_sns_datasource.dart';
import 'fake_location_module.dart';
import 'fake_sqflite_sns_datasource.dart';

void main() {
  runStudentWidgetTests();
}

void runStudentWidgetTests() {

  testWidgets('Dashboard shows news slides with text and image', (WidgetTester tester) async {
    await tester.pumpWidget(MultiProvider(
      providers: [
        Provider<HttpSnsDataSource>.value(value: FakeHttpSnsDataSource()),
        Provider<SqfliteSnsDataSource>.value(value: FakeSqfliteSnsDataSource()),
        Provider<LocationModule>.value(value: FakeLocationModule()),
        Provider<ConnectivityModule>.value(value: FakeConnectivityModule()),
      ],
      child: const MyApp(),
    ));

    // Wait for initial loading
    await tester.pumpAndSettle(Duration(milliseconds: 200));

    await tester.pumpAndSettle(const Duration(seconds: 1));

    expect(find.textContaining('Hospital de Viseu'), findsOneWidget);

    await tester.drag(find.byType(PageView), const Offset(-600.0, 0.0));
    await tester.pumpAndSettle();
    expect(find.textContaining('ULS Algarve'), findsOneWidget);

    await tester.drag(find.byType(PageView), const Offset(-600.0, 0.0));
    await tester.pumpAndSettle();
    expect(find.textContaining('Vila Franca de Xira'), findsOneWidget);
  });



  testWidgets('Dashboard shows message and generates password', (WidgetTester tester) async {
    await tester.pumpWidget(MultiProvider(
      providers: [
        Provider<HttpSnsDataSource>.value(value: FakeHttpSnsDataSource()),
        Provider<SqfliteSnsDataSource>.value(value: FakeSqfliteSnsDataSource()),
        Provider<LocationModule>.value(value: FakeLocationModule()),
        Provider<ConnectivityModule>.value(value: FakeConnectivityModule()),
      ],
      child: const MyApp(),
    ));

    // Wait for initial loading
    await tester.pumpAndSettle(Duration(milliseconds: 200));

    var dashboardItemFinder = find.byKey(Key('dashboard-bottom-bar-item'));
    expect(dashboardItemFinder, findsOneWidget);
    await tester.tap(dashboardItemFinder);
    await tester.pumpAndSettle();

    // Check if welcome message is shown on dashboard
    expect(find.textContaining('Cuidar da saúde é um ato de amor!'), findsOneWidget);

    final hospitalCard = find.text('hospital 1');
    expect(hospitalCard, findsOneWidget);
    await tester.tap(hospitalCard);
    await tester.pumpAndSettle();

    // Check if the "Gerar senha" button exists and tap it
    final generatePasswordButton = find.byKey(Key('generate-password-button'));
    expect(generatePasswordButton, findsOneWidget);
    await tester.tap(generatePasswordButton);
    await tester.pumpAndSettle();

    // Check if password text is displayed
    final passwordTextFinder = find.byKey(Key('generated-password-text'));
    expect(passwordTextFinder, findsOneWidget);
    final Text passwordText = tester.widget(passwordTextFinder);
    expect(passwordText.data, isNotEmpty, reason: "Deveria mostrar a senha gerada");
  });

    // Seus testes existentes...

    testWidgets('waiting timee', (WidgetTester tester) async {
      await tester.pumpWidget(MultiProvider(
        providers: [
          Provider<HttpSnsDataSource>.value(value: FakeHttpSnsDataSource()),
          Provider<SqfliteSnsDataSource>.value(value: FakeSqfliteSnsDataSource()),
          Provider<LocationModule>.value(value: FakeLocationModule()),
          Provider<ConnectivityModule>.value(value: FakeConnectivityModule()),
        ],
        child: const MyApp(),
      ));

      // have to wait for async initializations
      await tester.pumpAndSettle(Duration(milliseconds: 200));

      var listBottomBarItemFinder = find.byKey(Key('lista-bottom-bar-item'));
      expect(listBottomBarItemFinder, findsOneWidget);
      await tester.tap(listBottomBarItemFinder);
      await tester.pumpAndSettle();

      final Finder listViewFinder = find.byKey(Key('list-view'));
      expect(listViewFinder, findsOneWidget);
      final Finder listTilesFinder = find.descendant(of: listViewFinder, matching: find.byType(ListTile));
      final tiles = List.from(tester.widgetList<ListTile>(listTilesFinder));
      expect(tiles.length, 2);

      await tester.tap(listTilesFinder.first);
      await tester.pumpAndSettle();


      // O botão de mostrar tempo de espera deve estar presente
      final toggleButton = find.widgetWithText(ElevatedButton, 'Mostrar Tempo de Espera');
      expect(toggleButton, findsOneWidget);

      // Pressiona o botão para mostrar tempo de espera
      await tester.tap(toggleButton);
      await tester.pumpAndSettle(Duration(milliseconds: 200));



      // O texto do botão deve mudar para 'Ocultar Tempo de Espera'
      expect(find.widgetWithText(ElevatedButton, 'Ocultar Tempo de Espera'), findsOneWidget);

      // Pressiona o botão para ocultar tempo de espera
      await tester.tap(find.widgetWithText(ElevatedButton, 'Ocultar Tempo de Espera'));
      await tester.pumpAndSettle();


      // O botão volta a mostrar 'Mostrar Tempo de Espera'
      expect(find.widgetWithText(ElevatedButton, 'Mostrar Tempo de Espera'), findsOneWidget);
    });

  testWidgets('Offline evaluation test', (WidgetTester tester) async {
    // Instancias dos fakes
    final fakeHttpDatasource = FakeHttpSnsDataSource();
    final fakeSqfliteDatasource = FakeSqfliteSnsDataSource();
    final fakeConnectivityModule = FakeConnectivityModule();


    // Inicializa app com providers fakes
    await tester.pumpWidget(MultiProvider(
      providers: [
        Provider<HttpSnsDataSource>.value(value: fakeHttpDatasource),
        Provider<SqfliteSnsDataSource>.value(value: fakeSqfliteDatasource),
        Provider<ConnectivityModule>.value(value: fakeConnectivityModule),
      ],
      child: const MyApp(),
    ));

    await tester.pumpAndSettle(Duration(milliseconds: 200));

    var avaliacoesBottomBarItemFinder = find.byKey(Key('avaliacoes-bottom-bar-item'));
    expect(avaliacoesBottomBarItemFinder, findsOneWidget,
        reason: "Deveria existir um NavigationDestination com a key 'avaliacoes-bottom-bar-item'");
    await tester.tap(avaliacoesBottomBarItemFinder);
    await tester.pumpAndSettle();
    // Verifica o formulário de avaliação está presente e com os campos corretos

    final hospitalSelectionViewFinder = find.byKey(Key('evaluation-hospital-selection-field'));
    expect(hospitalSelectionViewFinder, findsOneWidget);
    TestableFormField<Hospital> hospitalSelectionFormField = tester.widget(hospitalSelectionViewFinder);

    final ratingViewFinder = find.byKey(Key('evaluation-rating-field'));
    expect(ratingViewFinder, findsOneWidget);
    TestableFormField<int> ratingFormField = tester.widget(ratingViewFinder);

    final dateTimeViewFinder = find.byKey(Key('evaluation-datetime-field'));
    expect(dateTimeViewFinder, findsOneWidget);
    TestableFormField<DateTime> dateTimeFormField = tester.widget(dateTimeViewFinder);

    final commentViewFinder = find.byKey(Key('evaluation-comment-field'));
    expect(commentViewFinder, findsOneWidget);
    TestableFormField<String> commentFormField = tester.widget(commentViewFinder);

    fakeConnectivityModule.online = false;

    final aHourAgo = DateTime.now().subtract(Duration(hours: 1));
    hospitalSelectionFormField.setValue(fakeHttpDatasource.hospitals[0]);
    dateTimeFormField.setValue(aHourAgo);
    commentFormField.setValue("No comments");


    // Submissão sem rating para validar mensagem de erro
    final submitButtonViewFinder = find.byKey(Key('evaluation-form-submit-button'));
    expect(submitButtonViewFinder, findsOneWidget);
    await tester.tap(submitButtonViewFinder);
    await tester.pumpAndSettle();

    // Deve mostrar erro por falta de nota
    expect(find.textContaining('Preencha a avaliação'), findsOneWidget);
    expect(find.byType(SnackBar), findsOneWidget);

    // Agora preenche a nota e submete
    ratingFormField.setValue(5);
    await tester.tap(submitButtonViewFinder);
    await tester.pumpAndSettle();



    // Navega para a lista de avaliações
    final listBottomBarItemFinder = find.byKey(Key('lista-bottom-bar-item'));
    expect(listBottomBarItemFinder, findsOneWidget);
    await tester.tap(listBottomBarItemFinder);
    await tester.pumpAndSettle();

    final listViewFinder = find.byKey(Key('list-view'));
    expect(listViewFinder, findsOneWidget);

    final listTilesFinder = find.descendant(of: listViewFinder, matching: find.byType(ListTile));
    final tiles = List.from(tester.widgetList<ListTile>(listTilesFinder));
    expect(tiles.length, greaterThanOrEqualTo(1));

    // Confirma os dados da avaliação na lista
    await tester.tap(listTilesFinder.first);
    await tester.pumpAndSettle();

    expect(find.text('hospital 1'), findsAtLeastNWidgets(1));
    final nowStr = DateFormat("dd/MM/yyyy HH:mm").format(aHourAgo);
    expect(find.text(nowStr), findsAtLeastNWidgets(1));
    expect(find.text('No comments'), findsAtLeastNWidgets(1));
  });


  testWidgets('Mapa screen changes camera position when a hospital marker is tapped', (WidgetTester tester) async {
    await tester.pumpWidget(MultiProvider(
      providers: [
        Provider<HttpSnsDataSource>.value(value: FakeHttpSnsDataSource()),
        Provider<SqfliteSnsDataSource>.value(value: FakeSqfliteSnsDataSource()),
        Provider<LocationModule>.value(value: FakeLocationModule()),
        Provider<ConnectivityModule>.value(value: FakeConnectivityModule()),
      ],
      child: const MyApp(),
    ));

    await tester.pumpAndSettle(Duration(milliseconds: 200));

    var mapBottomBarItemFinder = find.byKey(Key('mapa-bottom-bar-item'));
    await tester.tap(mapBottomBarItemFinder);
    await tester.pumpAndSettle();

    final mapFinder = find.byType(GoogleMap);
    expect(mapFinder, findsOneWidget);
  });






}
